export default class hasilGenerate {
  async render() {
    return `
      <section class="result-section">
        <div class="notebook-wrapper">
          <img src="./images/notebook-bg.png" alt="Notebook Background" class="notebook-img" />

          <div class="notebook-content">
            <h1><span class="bold">HASIL</span> <span class="pink">ANALISIS</span></h1>

            <div class="result-grid">
              <div class="personal-data">
                <h3>Data Pribadi</h3>
                <ul>
                  <li>Jonathan Sovisa</li>
                  <li>Usia - 21 Tahun</li>
                  <li>Tinggi Badan - 161 cm</li>
                  <li>Berat Badan - 61 kg</li>
                  <li>Sit Up Counts - 50 Kali</li>
                  <li>Broad Jump - 25 cm</li>
                </ul>
              </div>

              <div class="recommendation">
                <h3>Rekomendasi Latihan</h3>
                <div class="recommendation-box"></div>
              </div>
            </div>

            <div class="category-box">
              ANDA MASUK KE KELAS KATEGORI “<b>B</b>”
            </div>
          </div>
        </div>
      </section>

    `;
  }

  async afterRender() {
    // Do your job here
  }
}
